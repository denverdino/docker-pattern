This script package is used on DB2 parts in patterns. It creates a database with a name specified by the user. It creates this database as the db2inst1 DB2 user.
