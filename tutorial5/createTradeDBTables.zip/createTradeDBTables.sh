#!/bin/sh
#******************************************************************************
#
#  Source File Name = createTradeDBTables.sh
#
#  The following sample of source code ("Sample") is owned by International
#  Business Machines Corporation or one of its subsidiaries ("IBM") and is
#  copyrighted and licensed, not sold. You may use, copy, modify, and
#  distribute the Sample in any form without payment to IBM, for the purpose of
#  assisting you in the development of your applications.
#
#  The Sample code is provided to you on an "AS IS" basis, without warranty of
#  any kind. IBM HEREBY EXPRESSLY DISCLAIMS ALL WARRANTIES, EITHER EXPRESS OR
#  IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
#  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. Some jurisdictions do
#  not allow for the exclusion or limitation of implied warranties, so the above
#  limitations or exclusions may not apply to you. IBM shall not be liable for
#  any damages you suffer as a result of using, copying, modifying or
#  distributing the Sample, even if IBM has been advised of the possibility of
#  such damages.
#
#  Function =
#   Create a DB2 database
#
#  Operating System = Linux, AIX
#
#  Authors =
#   Leons Petrazickis
#   Dustin Amrhein
#
#******************************************************************************

#echo "DB2INSTANCE=db2inst1" >> /etc/virtualimage.properties

# get deploy-time parameters
. /etc/virtualimage.properties

echo "DATABASE_NAME=$DATABASE_NAME" 
echo "DB_ADMIN_USERNAME=$DB_ADMIN_USERNAME"

#find where DB2 is installed:
#added addnl "if" parm suggested by Leons Petrazickis on 8/29/2012
#and additional testing for fallback guess

if [ -f /usr/local/bin/db2ls -a -n "`/usr/local/bin/db2ls`" ]; 
then
   db2found=yes
   db2path=`/usr/local/bin/db2ls | sed '$!d' | sed 's/ .*//'`
   echo "DB2 installation found at " $db2path
else
   # attempt to "version-proof" the fallthrough
   db2path=`ls -d /opt/ibm/db2/V*`
   echo "Guessing that DB2 installation can be found at" $db2path
   # current images may be installed at:
   #db2path='/opt/ibm/db2/V9.7'
   #db2path='/opt/ibm/db2/V10.1'
   if [ ! -d $db2path ] ; then
     echo "DB2 not found at expected location"
     echo >&2 "DB2 not found at expected location"
     echo "exiting script"
     echo >2"exiting script"
     exit 1
   fi
fi

# echo  -c "$db2path/bin/db2 SET CLIENT DISCONNECT EXPLICIT"
# $db2path/bin/db2 "SET CLIENT DISCONNECT EXPLICIT"
# echo rc= $?

echo "$db2path/bin/db2 CREATE DATABASE $DATABASE_NAME"
$db2path/bin/db2 "CREATE DATABASE $DATABASE_NAME"
echo rc= $?
echo "$db2path/bin/db2 CONNECT TO $DATABASE_NAME"
$db2path/bin/db2 "CONNECT TO $DATABASE_NAME"
echo rc= $?
echo "$db2path/bin/db2 -tvf /tmp/createTradeDBTables/DropTables.ddl"
$db2path/bin/db2 -tvf /tmp/createTradeDBTables/DropTables.ddl
rc=$?

if [ $rc -lt 8 ]
   then echo "$db2path/bin/db2 -tvf /tmp/createTradeDBTables/CreateTables.ddl"
		$db2path/bin/db2 -tvf /tmp/createTradeDBTables/CreateTables.ddl
		rc=$?
		if [ $rc -lt 8 ]
		   then echo "rc = $rc -- OK!"
		   else echo rc=$rc -- SQL failure
			exit $rc
		fi 
   else echo rc=$rc -- SQL failure
   	exit $rc
fi 

