#!/bin/sh

docker load < amb_img.tar.gz
REGISTRY_IP=127.0.0.1
#extract the port on which the registry container is bound, at this time there's only one container running.
#grep the line like "HostPort":5000
port=`docker inspect $(docker ps -q)|grep HostPort|head -1|cut -d: -f2|xargs echo`
if [ $? -lt 0 -o ${#port} -eq 0 ]; then
	echo "failed to get the port via docker inspect, set to default 5000"
	port=5000
fi
echo "the port: $port"
docker tag svendowideit/ambassador $REGISTRY_IP:$port/pure/ambassador
docker_version=`docker version | head -1 | cut -b 17-`
OPTIONS_STR="OPTIONS"
if [ $docker_version == "1.3.3" ]; then
	OPTIONS_STR="other_args"
fi 
echo "$OPTIONS_STR='--insecure-registry 0.0.0.0/0'" > /etc/sysconfig/docker
#service cmd also works on rhel 7 img
service docker restart
sleep 5
docker push $REGISTRY_IP:$port/pure/ambassador
